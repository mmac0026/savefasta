#' Write .fasta to file
#'
#' Generate a .fasta file from a data.frame using a name column as your sequence name,
#' and a sequence column that defines your sequence data.
#'
#' @param data A data frame that contains both name and sequence columns.
#' @param nameCol A string that is the column name of the column defining sample names.
#' @param seqCol A string that is the column name of the column defining sequences.
#' @param filename A name for the new .fasta file.
#'
#' @import dplyr
#'
#' @export
#'
#' @examples
#' saveAsFasta(exampleData2, 'ID', 'V1_V2', 'example2.fasta')
#'
#' @return This function does not return anything within R. A .fasta file is generated with
#' the sequences listed in .fasta format with the identifiers from the name column.
#'
#' @author Matthew Macowan \email{matthew.macowan@monash.edu.au}
saveAsFasta <-
function(data, nameCol, seqCol, filename) {

  # Check whether data is a data.frame
  if(!is.data.frame(data)){
    stop('Error: data must be of class "data.frame".')
  }

  # Check whether filename is a string
  if(!is.character(nameCol)){
    stop('Error: nameCol (name column) must be of class "character".')
  }

  # Check whether filename is a string
  if(!is.character(seqCol)){
    stop('Error: seqCol (sequence column) must be of class "character".')
  }

  # Check whether filename is a string
  if(!is.character(filename)){
    stop('Error: filename must be of class "character".')
  }

  data <- data %>%
    select(nameCol, seqCol)
  colnames(data) <- c('name', 'seq')

  writeFasta <- function(data, filename){
    fastaLines <- c()
    for (rowNum in 1:nrow(data)){
      fastaLines <- c(fastaLines, as.character(paste('>', data[rowNum,'name'], sep = '')))
      fastaLines <- c(fastaLines,as.character(data[rowNum,'seq']))
    }
    fileConn <- file(filename)
    writeLines(fastaLines, fileConn)
    close(fileConn)
  }

  writeFasta(data, filename)
}
